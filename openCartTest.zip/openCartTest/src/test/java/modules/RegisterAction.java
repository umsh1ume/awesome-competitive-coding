package modules;



import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import helpers.DataRegister;
import pageobjects.RegisterAccount;



public class RegisterAction {
	
	
public static void Execute(WebDriver driver) throws Exception{
	
	
	
	
	
		ArrayList<ArrayList<String> > mydata = DataRegister.data();
		ArrayList<String> values= mydata.get(0); 
		RegisterAccount.firstName.sendKeys(values.get(0));
		RegisterAccount.lastName.sendKeys(values.get(1));
		RegisterAccount.email.sendKeys(values.get(2));
		RegisterAccount.telephone.sendKeys(values.get(3));
		RegisterAccount.password.sendKeys(values.get(4));
		RegisterAccount.cnfPassword.sendKeys(values.get(5));
		RegisterAccount.subscribeRadioNo.click();
		RegisterAccount.policyCheckBox.click();
		RegisterAccount.continueButton.click();
		
		Reporter.log("Details Entered Successfully");
	}
}
