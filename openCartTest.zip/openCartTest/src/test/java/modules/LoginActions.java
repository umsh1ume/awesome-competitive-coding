package modules;

import java.util.List;

import org.openqa.selenium.WebDriver;

import cucumber.api.DataTable;
import pageobjects.HomePage;
import pageobjects.LoginPage;

public class LoginActions {
		
	public static void Execute(WebDriver driver,DataTable logindata) throws Exception{
		HomePage.myAccount.click();
		HomePage.login.click();
		List<List<String>> data = logindata.raw();
		LoginPage.email.sendKeys(data.get(0).get(0));
		LoginPage.password.sendKeys(data.get(0).get(1));
		LoginPage.loginBtn.click();
	}
}