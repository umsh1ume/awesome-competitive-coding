package modules;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import org.testng.Reporter;

import helpers.Log;
import pageobjects.CheckOutPage;
import pageobjects.HomePage;
import pageobjects.SearchProductPage;

public class CheckOutDetailsAction {
	
public static void LoginUser(WebDriver driver) throws Exception{
		
		
		/*CheckOutPage.GuestCheckOut.click();
		Log.info("As A Guest" );*/
	   HomePage.my_account_dropdown.click();
	   Log.info("My Account Clicked" );
		
		/*CheckOutPage.ContinueCustomer.click();
		Log.info("Continue Clicked" );*/
	   HomePage.login.click();
	   
	   HomePage.email.sendKeys("ankit.abc@abc.com");
	   HomePage.password.sendKeys("asdfghjkl");
	   HomePage.login_button.click();
		
		
		

		Reporter.log("Login is successfully perfomred");

	}
public static void ExecuteBillingDetails(WebDriver driver) throws Exception{
	
	Thread.sleep(4000);
	CheckOutPage.ContinueBilling.click();
	Thread.sleep(4000);
	CheckOutPage.ContinueDeliveryDetails.click();
	Thread.sleep(4000);
	CheckOutPage.ContinueDeliveryMethod.click();
	Thread.sleep(5000);
	CheckOutPage.TermsAndCondCheck.click();
	Thread.sleep(4000);
	CheckOutPage.ContinuePayment.click();
	Thread.sleep(4000);
	CheckOutPage.ConfirmOrder.click();
	Thread.sleep(4000);
    Assert.assertEquals(CheckOutPage.OrderPlaceTitle.getText(),"Your order has been placed!");
    Thread.sleep(4000);
    CheckOutPage.ContinueOrder.click();
	
	
	

	Reporter.log("Add to Cart Action is successfully perfomred");

}

}
