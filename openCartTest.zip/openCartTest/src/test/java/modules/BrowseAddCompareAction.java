package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageobjects.BaseClass;
import pageobjects.HomePage;

public class BrowseAddCompareAction extends BaseClass {

	public BrowseAddCompareAction(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public static void Execute(WebDriver driver) throws Exception{
		HomePage.desktop.click();
		HomePage.allDesktopLink.click();
		driver.findElement(By.xpath("//*[@id=\"list-view\"]"));
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div[1]/div/div[2]/div[2]/button[3]")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div[2]/div/div[2]/div[2]/button[3]")).click();
		
		try{
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("product comparison")));
		driver.findElement(By.linkText("product comparison")).click();
		System.out.println("exception not");
		}
		catch(Exception e){
		System.out.println("exception yes");
		WebDriverWait wait = new WebDriverWait(driver,30);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("product comparison")));
			driver.findElement(By.linkText("product comparison")).click();
		}
		
	}
	

}
