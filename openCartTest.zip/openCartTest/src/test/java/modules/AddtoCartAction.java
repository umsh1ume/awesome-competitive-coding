package modules;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import helpers.Log;
import pageobjects.HomePage;
import pageobjects.SearchProductPage;

public class AddtoCartAction {
public static void Execute(WebDriver driver) throws Exception{
		
		
		SearchProductPage.AddToCartMacBook.click();;
		Log.info("Added mac to cart" );
		Thread.sleep(5000);
		SearchProductPage.ViewAddedProd.click();
		Log.info("View Added Product" );
		
		SearchProductPage.CheckOut.click();
		Log.info("Navigating to checkout page" );
		

		Reporter.log("Add to Cart Action is successfully perfomred");

	}
}
