package modules;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import pageobjects.AddAddressPage;

public class AddAddressAction {
	public static void Execute(WebDriver driver) throws Exception{
		AddAddressPage.firstName.sendKeys("asdfghj");
		AddAddressPage.lastName.sendKeys("asdfghj");
		AddAddressPage.companyName.sendKeys("asdfghj");
		AddAddressPage.Address1.sendKeys("asdfghj");
		AddAddressPage.Address2.sendKeys("asdfghj");
		AddAddressPage.city.sendKeys("asdfghj");
		AddAddressPage.postCode.sendKeys("12345678");
		Select sc= new Select(AddAddressPage.country);
		sc.selectByIndex(1);
		
		Select ss= new Select(AddAddressPage.state);
		ss.selectByIndex(1);
		
		AddAddressPage.isDefault.click();
		AddAddressPage.submitBtn.click();
	}
}
