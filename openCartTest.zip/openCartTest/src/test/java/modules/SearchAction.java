package modules;

import helpers.Log;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import pageobjects.HomePage;


public class SearchAction {

	public static void Execute(WebDriver driver) throws Exception{
		
		
		HomePage.search_box.sendKeys("mac");
		Log.info("Data is entered in search box" );

		HomePage.search_button.click();
		Log.info("Clicked on search button" );

		/*Log.info(" is entered in UserName text box" );
		
		LoginPage.password.sendKeys(map.get("password"));
		Log.info(" is entered in Password text box" );

		LoginPage.signin_button.click();
		Log.info("Click action is performed on Submit button");*/

		Reporter.log("Search Action is successfully perfomred");

	}
}
