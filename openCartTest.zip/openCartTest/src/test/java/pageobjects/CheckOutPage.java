package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CheckOutPage extends BaseClass{

	public CheckOutPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(how=How.XPATH, using="//*[@id='button-shipping-address']")
	public static WebElement ContinueDeliveryDetails;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/div[2]/label/input")
	public static WebElement GuestCheckOut;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/input")
	public static WebElement ContinueCustomer;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[1]/fieldset/div[2]/input")
	public static WebElement FirstNameText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[1]/fieldset/div[3]/input")
	public static WebElement LastNameText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[1]/fieldset/div[4]/input")
	public static WebElement EmailText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[1]/fieldset/div[5]/input")
	public static WebElement TelephoneText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[2]/fieldset/div[2]/input")
	public static WebElement Address1Text;

	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[2]/fieldset/div[4]/input")
	public static WebElement CityText;

	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[2]/fieldset/div[5]/input")
	public static WebElement PostCodeText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[2]/fieldset/div[6]/select")
	public static WebElement CountryText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[1]/div[2]/fieldset/div[7]/select")
	public static WebElement StateText;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div[2]/div/div[2]/label/input")
	public static WebElement DeliveryBillingCheck;
	
	@FindBy(how=How.XPATH, using="//*[@id='button-payment-address']")
	public static WebElement ContinueBilling;
	
	@FindBy(how=How.XPATH, using="//*[@id='button-shipping-method']")
	public static WebElement ContinueDeliveryMethod;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[5]/div[2]/div/div[2]/div/input[1]")
	public static WebElement TermsAndCondCheck;
	

	@FindBy(how=How.XPATH, using="//*[@id='button-payment-method']")
	public static WebElement ContinuePayment;
	
	@FindBy(how=How.XPATH, using="//*[@id='button-confirm']")
	public static WebElement ConfirmOrder;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/h1")
	public static WebElement OrderPlaceTitle;
	
	@FindBy(how=How.XPATH, using="//*[@id='content']/div/div/a")
	public static WebElement ContinueOrder;
	
}
