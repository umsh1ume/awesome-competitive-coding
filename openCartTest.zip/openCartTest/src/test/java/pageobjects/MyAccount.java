package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MyAccount extends BaseClass {

	public MyAccount(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(how=How.PARTIAL_LINK_TEXT, using="Change your password")
	public static WebElement changePassLink;
	
	@FindBy(how=How.PARTIAL_LINK_TEXT, using="Modify your address book entries")
	public static WebElement modifyAddressLink;
}
