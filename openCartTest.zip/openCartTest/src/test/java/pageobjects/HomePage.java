package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage extends BaseClass{

	public HomePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(how=How.XPATH, using="/html/body/nav/div/div[2]/ul/li[2]/a/span[1]")
	public static WebElement my_account_dropdown;
	
	/*@FindBy(how=How.XPATH, using="/html/body/nav/div/div[2]/ul/li[2]/ul/li[2]/a")
	public static WebElement login;*/
	
	@FindBy(how=How.NAME, using="email")
	public static WebElement email;
	
	@FindBy(how=How.NAME, using="password")
	public static WebElement password;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div/form/input")
	public static WebElement login_button;
	
	@FindBy(how=How.NAME, using="search")
	public static WebElement search_box;
	
	
	@FindBy(how=How.XPATH, using="/html/body/header/div/div/div[2]/div/span/button")
	public static WebElement search_button;
	
	@FindBy(how=How.XPATH, using="/html/body/div[1]/nav/div[2]/ul/li[1]/a")
	public static WebElement desktop_button;
	
	@FindBy(how=How.XPATH, using="/html/body/nav/div/div[2]/ul/li[2]/a/span[1]")	
	public static WebElement myAccount;
	
	@FindBy(how=How.XPATH, using="/html/body/nav/div/div[2]/ul/li[2]/ul/li[1]/a")
	public static WebElement register;
	
	@FindBy(how=How.LINK_TEXT, using="Login")
	public static WebElement login;
	
	@FindBy(how=How.XPATH, using="/html/body/div[1]/nav/div[2]/ul/li[1]/a")
	public static WebElement desktop;
	
	@FindBy(how=How.PARTIAL_LINK_TEXT, using="Show All Desktops")
	public static WebElement allDesktopLink;
	
	

}
