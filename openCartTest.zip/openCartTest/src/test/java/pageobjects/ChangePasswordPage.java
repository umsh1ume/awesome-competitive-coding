package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ChangePasswordPage extends BaseClass{

	public ChangePasswordPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	@FindBy(how=How.ID, using="input-password")
	public static WebElement password;
	
	@FindBy(how=How.ID, using="input-confirm")
	public static WebElement cnfPassword;
	
	
	@FindBy(how=How.XPATH  , using="/html/body/div[2]/div/div/form/div/div[2]/input")
	public static WebElement continueBtn;
}
