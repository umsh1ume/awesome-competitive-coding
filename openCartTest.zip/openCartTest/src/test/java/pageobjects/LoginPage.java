package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage extends BaseClass{

	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(how=How.ID, using="input-email")
	public static WebElement email;
	
	@FindBy(how=How.ID, using="input-password")
	public static WebElement password;
	
	
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div/div[2]/div/form/input")
	public static WebElement loginBtn;
	
}
