package pageobjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AddAddressPage extends BaseClass{

	public AddAddressPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(how=How.ID, using="input-firstname")
	public static WebElement firstName;
	
	
	
	@FindBy(how=How.ID, using="input-company")
	public static WebElement companyName;
	
	@FindBy(how=How.ID, using="input-address-1")
	public static WebElement Address1;
	
	@FindBy(how=How.ID, using="input-address-2")
	public static WebElement Address2;
	
	@FindBy(how=How.ID, using="input-city")
	public static WebElement city;
	
	@FindBy(how=How.ID, using="input-postcode")
	public static WebElement postCode;
	
	@FindBy(how=How.ID, using="input-lastname")
	public static WebElement lastName;
	
	@FindBy(how=How.ID, using="input-country")
	public  static WebElement country;
	
	
	@FindBy(how=How.ID, using="input-zone")
	public static WebElement state;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/form/fieldset/div[10]/div/label[2]/input")
	public static WebElement isDefault;
	
	
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/form/div/div[2]/input")
	public static WebElement submitBtn;
}
