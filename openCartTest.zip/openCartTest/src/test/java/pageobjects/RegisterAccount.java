package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterAccount extends BaseClass {

	public RegisterAccount(WebDriver driver) {
		super(driver);
		
	}
	
	@FindBy(how=How.ID, using="input-firstname")
	public static WebElement firstName;
	
	@FindBy(how=How.ID, using="input-lastname")
	public static WebElement lastName;
	
	@FindBy(how=How.ID, using="input-email")
	public static WebElement email;
	
	@FindBy(how=How.ID, using="input-telephone")
	public static WebElement telephone;
	
	@FindBy(how=How.ID, using="input-password")
	public static WebElement password;
	
	@FindBy(how=How.ID, using="input-confirm")
	public static WebElement cnfPassword;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/form/fieldset[3]/div/div/label[2]/input")
	public static WebElement subscribeRadioNo;
	
	@FindBy(how=How.NAME, using="agree")
	public static WebElement policyCheckBox;
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/form/div/div/input[2]")
	public static WebElement continueButton;
	
}
