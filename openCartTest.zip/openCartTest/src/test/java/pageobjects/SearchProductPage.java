package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SearchProductPage extends BaseClass{

	public SearchProductPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(how=How.XPATH, using="/html/body/div[2]/div/div/div[3]/div[3]/div/div[2]/div[2]/button[1]")
	public static WebElement AddToCartMacBook;
	
	@FindBy(how=How.XPATH, using="/html/body/header/div/div/div[3]/div/button")
	//@FindBy(how=How.ID, using="cart")
	public static WebElement ViewAddedProd;
	
	@FindBy(how=How.XPATH, using="/html/body/header/div/div/div[3]/div/ul/li[2]/div/p/a[2]/strong")
	public static WebElement CheckOut;
	

}
