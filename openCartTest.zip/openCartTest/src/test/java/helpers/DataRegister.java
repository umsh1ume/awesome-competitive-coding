package helpers;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataRegister {
 
	
		
		public static ArrayList<ArrayList<String>> data(){
			ArrayList<ArrayList<String>> mydata = new ArrayList<ArrayList<String>>();
			try{
				File file = new File("C://Users/H.P/Desktop/program/openCartTest/src/test/resources/testData/OpencartTestData.xlsx");
				FileInputStream fs = new FileInputStream(file);
				Workbook workbook = new XSSFWorkbook(fs);
				XSSFSheet sheet = (XSSFSheet) workbook.getSheet("Register");
				System.out.println(sheet.getSheetName());
				System.out.println(sheet.getPhysicalNumberOfRows());
				for(int i=0;i<sheet.getPhysicalNumberOfRows();i++)
				{
					Row currentRow = sheet.getRow(i);
					ArrayList<String> curr = new ArrayList<String>();
					for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
					{
						Cell currentCell = currentRow.getCell(j);
						currentCell.setCellType(Cell.CELL_TYPE_STRING);
						switch (currentCell.getCellType())
						{
						case Cell.CELL_TYPE_STRING:
							System.out.print(currentCell.getStringCellValue() + "\t");
							//curr.add(currentCell.getStringCellValue());
							curr.add(currentCell.getStringCellValue());
							break;
						}

					}
					mydata.add(curr);
				}

				fs.close();
			}
			
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			return mydata;
		}
}
