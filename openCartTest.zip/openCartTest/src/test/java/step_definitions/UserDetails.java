package step_definitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.AddtoCartAction;
import modules.CheckOutDetailsAction;
import modules.SearchAction;
import pageobjects.CheckOutPage;
import pageobjects.HomePage;
import pageobjects.SearchProductPage;

public class UserDetails {
	
	
	 public WebDriver driver;
	    
	    public UserDetails()
	    {
	    	driver = Hooks.driver;
	    }
	    
	   

	    
	    @When("^I open opencart website and Login$")
	    public void i_open_opencart_website_and_Login() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	 driver.get("http://demo.opencart.com");
	    	PageFactory.initElements(driver, HomePage.class);
			//PageFactory.initElements(driver, LoginPage.class);
	         CheckOutDetailsAction.LoginUser(driver);
	         
	    }

	    @And("^I search for the product$")
	    public void i_search_for_the_product() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	//.initElements(driver, CheckOutPage.class);
			//PageFactory.initElements(driver, LoginPage.class);
	    	// CheckOutDetailsAction.ExecuteBillingDetails(driver);
	    	PageFactory.initElements(driver, HomePage.class);
	    	 SearchAction.Execute(driver);
	      
	    }
	    
	    @Then("^I add the product to cart and checkout$")
	    public void i_add_the_product_to_cart_and_checkout() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	PageFactory.initElements(driver, SearchProductPage.class);
	    	AddtoCartAction.Execute(driver);
	    	PageFactory.initElements(driver, CheckOutPage.class);
			//PageFactory.initElements(driver, LoginPage.class);
	    	CheckOutDetailsAction.ExecuteBillingDetails(driver);
	      
	    }

}
