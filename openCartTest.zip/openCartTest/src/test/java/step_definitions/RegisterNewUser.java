package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataRegister;
import modules.RegisterAction;
import pageobjects.RegisterAccount;

public class RegisterNewUser {
	public WebDriver driver;
	
	public RegisterNewUser(){
		driver=Hooks.driver;
	}
	
	 @Given("^User is on home page$")
	    public void user_is_on_home_page() throws Throwable{
	    	driver.get("https://demo.opencart.com/");
	    	assertEquals("Your Store",driver.getTitle());
	    }
	    
	    @When("^I click on my account$")
	    public void i_click_on_my_accounts() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/a")).click();
	    	
	    }

	    @And("^I click on register$")
	    public void i_click_on_my_register() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[2]/ul/li[1]/a")).click();
	    }

	    @Then("^registration page opens$")
	    public void registration_page_opens() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	assertEquals("Register Account", driver.getTitle());
	    }
	    @Test(dataProvider="registerdata")
	    @Then("^I Enter required Details$")
	    public void i_enter_required_Details() throws Throwable {
	    	PageFactory.initElements(driver, RegisterAccount.class);
	    	
	    	RegisterAction.Execute(driver);
	    }
	    
	    @DataProvider(name="registerdata")
	    public Object[][] datapass(){
	    	Object[][] data=new Object[2][6];
	    	ArrayList<ArrayList<String> > mydata = DataRegister.data();
			for(int i=0;i<2;i++){
				for(int j=0;j<6;j++){
					data[i][j]= mydata.get(i).get(j);
				}
			}
			return data;
	
	    }
	    
}
