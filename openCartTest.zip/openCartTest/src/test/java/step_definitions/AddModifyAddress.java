package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.junit.Ignore;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.AddAddressAction;
import pageobjects.AddAddressPage;
import pageobjects.MyAccount;

public class AddModifyAddress {
	public WebDriver driver;
	
	public AddModifyAddress(){
		driver=Hooks.driver;
	}

	@Given("^user is on myaccount page to Add Address$")
    public void user_is_on_opencart_home_page_to_Add_Address() throws Throwable{
		assertEquals("My Account", driver.getTitle());
    }
	

	@When("^I Click on modify Address link$")
	public void I_Click_on_modify_Address_link() throws Throwable{
		PageFactory.initElements(driver, MyAccount.class);
		MyAccount.modifyAddressLink.click();
	}
	
	@Then("^I add Address$")
	public void i_add_Address() throws Throwable{
		driver.findElement(By.partialLinkText("New Address")).click();
		PageFactory.initElements(driver, AddAddressPage.class);
		AddAddressAction.Execute(driver);
	}
}
