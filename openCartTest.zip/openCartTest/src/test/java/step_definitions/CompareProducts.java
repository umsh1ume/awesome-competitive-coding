package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import modules.BrowseAddCompareAction;
import pageobjects.HomePage;

public class CompareProducts {
public WebDriver driver;
	
	public CompareProducts(){
		driver=Hooks.driver;
	}
	
	@Given("^user in on home page for browsing$")
	public void user_in_on_home_page_for_browsing() throws Throwable{
		driver.get("https://demo.opencart.com/");
    	assertEquals("Your Store",driver.getTitle());
	}
	
	@Then("^user browses and adds two product for compare$")
	public void user_browses_and_adds_two_product_for_compare() throws Throwable{
		PageFactory.initElements(driver, HomePage.class);
		BrowseAddCompareAction.Execute(driver);
		assertEquals("Product Comparison", driver.getTitle());
	}
}
