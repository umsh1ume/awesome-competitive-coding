package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.LoginActions;
import pageobjects.ChangePasswordPage;
import pageobjects.HomePage;
import pageobjects.LoginPage;
import pageobjects.MyAccount;

public class ChangePassword {
			
	public WebDriver driver;
	
	public ChangePassword(){
		driver=Hooks.driver;
	}
	
	 
	@Given("^user is on myaccount page$")
	public void user_is_on_myaccount_page() throws Throwable{
		assertEquals("My Account", driver.getTitle());
	}
	
	 
	
	 @Then("^I Click on change password link$")
	 	public void i_click_on_change_password_link() throws Throwable{
		 PageFactory.initElements(driver, MyAccount.class);
		 MyAccount.changePassLink.click();
	 }
	 @Then("^I Change my password$")
	 	public void i_Change_my_password() throws Throwable{
		 PageFactory.initElements(driver, ChangePasswordPage.class);
		 ChangePasswordPage.password.sendKeys("asdfghjkl");
		 ChangePasswordPage.cnfPassword.sendKeys("asdfghjkl");
		 ChangePasswordPage.continueBtn.click();
		 
		 String successText=driver.findElement(By.xpath("/html/body/div[2]/div[1]")).getText();
		 assertEquals(true, successText.contains("Your password has been successfully updated"));
	 }
	 
	 
}
