package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.AddtoCartAction;
import modules.SearchAction;
import pageobjects.HomePage;
import pageobjects.SearchProductPage;



public class SearchCheckOut{
    public WebDriver driver;
    
    public SearchCheckOut()
    {
    	driver = Hooks.driver;
    }
    
    @When("^I open opencart website$")
    public void i_open_opencart_website() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.get("http://demo.opencart.com");
    }

    @And("^I search for product$")
    public void i_search_for_product() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	PageFactory.initElements(driver, HomePage.class);
		//PageFactory.initElements(driver, LoginPage.class);
    	SearchAction.Execute(driver);
      
    }
    
    @Then("^I add the product to cart$")
    public void i_add_the_product_to_cart() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	PageFactory.initElements(driver, SearchProductPage.class);
		//PageFactory.initElements(driver, LoginPage.class);
    	AddtoCartAction.Execute(driver);
      
    }
    
}