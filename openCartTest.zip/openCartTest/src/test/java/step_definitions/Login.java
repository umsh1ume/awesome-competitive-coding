package step_definitions;

import static org.testng.AssertJUnit.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import modules.LoginActions;
import pageobjects.HomePage;
import pageobjects.LoginPage;

public class Login {
		
public WebDriver driver;
	
	public Login(){
		driver=Hooks.driver;
	}
	
	 @Given("^User is on opencart home page$")
	    public void user_is_on_opencart_home_page() throws Throwable{
	    	driver.get("https://demo.opencart.com/");
	    	assertEquals("Your Store",driver.getTitle());
	    }
	 
	 @When("^I login on website$")
	 	public void i_login_on_website(DataTable logindata) throws Throwable{
		 PageFactory.initElements(driver, HomePage.class);
		 PageFactory.initElements(driver, LoginPage.class);
		 
		 LoginActions.Execute(driver,logindata);
		 
	 }
	 
}
